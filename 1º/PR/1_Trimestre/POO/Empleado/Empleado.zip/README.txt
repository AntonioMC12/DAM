Hay dos carpetas, ya que el programa corre de manera diferente según el sistema operativo en el que se encuentre.

En cada carpeta hay un archivo que permite la compilacion y la creación de la documentación de manera automática.

WINDOWS:

  Abra el "cmd" en la ruta de la carpeta Windows y ejecute el archivo "compila.bat", él compilará, creará la docu-
  mentación y ejecutará el programa de forma automática.
  Para ejecutar el programa sin hacer uso del "compila.bat" y este ya ha sido usado con anterioridad, dirígase a la
  carpeta "Windows/dist" y ejecute "java Ejecutable".

Linux:

  Abra el terminal en la ruta de la carpeta Linux y ejecute "sh compila.sh", él compilará, creará la documentación y
  ejecutará el programa de forma automática.
  Para ejecutar el programa sin hacer uso del "compila.sh" y este ya ha sido usado con anterioridad, dirígase a la
  carpeta "Linux/dist" y ejecute "java Ejecutable".


La diferencia entre el programa en Linux y Windows es que en Linux utilizo una serie de códigos "ANSI" que me permite
cambiar los colores del fondo y letras de la terminal, pero la consola de Windows no lo soporta, por eso lo he separado.

Trabajo realizado por: [Antonio Muñoz Cubero] 1º Ciclo Superior DAM. IES Francisco de los Ríos.